#ifndef tnode_h
#define tnode_h

struct tnode
{
	int cnt;
	char key[1004];
	struct tnode* RC;
	struct tnode* LC;
};

#endif
