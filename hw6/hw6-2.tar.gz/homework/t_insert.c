#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "tnode.h" 

struct tnode* t_insert( struct tnode* treep , char word[] )
{
	int c;
	struct tnode* ptr;
	ptr = (struct tnode*)malloc(sizeof(struct tnode));
	
	if( treep == NULL )
	{
		strcpy( ptr->key , word );
		ptr->cnt = 1;
		ptr->RC = NULL;
		ptr->LC = NULL;
		treep = ptr;
		return treep;
	}
	
	c = strcmp( treep->key , word );
	
	if( c > 0 )
	{
		ptr = t_insert( treep->LC , word );
		treep->LC = ptr;
		return treep;
	}
	
	else if( c == 0 )
	{
		treep->cnt++;
		return treep;	
	}
	
	else if( c < 0 )
	{
		ptr = t_insert( treep->RC , word );
		treep->RC = ptr;
		return treep;
	}
	return NULL;
}
