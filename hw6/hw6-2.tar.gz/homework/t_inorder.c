#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include "tnode.h"
void t_inorder( struct tnode *treep )
{
	if( treep != NULL )
	{
		t_inorder( treep->LC );
		if( treep->cnt != 0 )
		printf( "%s\t%d\n",treep->key , treep->cnt );
		t_inorder( treep->RC );
	}
}
