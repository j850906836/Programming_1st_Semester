#ifndef t_pos_h
#define t_pos_h

struct tnode** pos( struct tnode * , struct tnode ** );

#endif
