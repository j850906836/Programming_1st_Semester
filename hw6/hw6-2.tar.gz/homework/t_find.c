#include <stddef.h>
#include <string.h>
#include "tnode.h"
struct tnode* t_find( struct tnode* treep , char word[] )
{
	int c;
		
	if( treep == NULL )
		return NULL;
	c = strcmp( treep->key , word);
	if( c > 0 )
	{
		if( treep->LC == NULL )
			return NULL;
		else
		return	t_find( treep->LC , word );
	}
	else if( c == 0 )
	{
		return treep;
	}
	else if( c < 0 )
	{
		if( treep->RC == NULL )
			return NULL;
		else
		return	t_find( treep->RC , word );
	}
		
	return NULL;
}
