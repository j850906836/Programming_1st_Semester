#ifndef t_find_h
#define t_find_h

struct tnode* t_find( struct tnode* treep , char word []);

#endif
