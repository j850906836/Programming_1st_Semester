#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "tnode.h"
#include "t_pos.h"
int mycompare( const void * , const void * );
struct tnode** t_count( struct tnode* , int );
struct tnode** t_count( struct tnode* treep , int len)
{
	struct tnode **ptr = NULL;
	ptr = (struct tnode**)malloc(sizeof(struct tnode*)*1004);

	pos(treep,ptr);

	qsort( ptr,(size_t)len,sizeof(*ptr),mycompare);
	return ptr;
}

int mycompare( const void *x , const void *y )
{
	struct tnode *a = *(struct tnode *const*)x;
	struct tnode *b = *(struct tnode *const*)y;
	int c = 0;
	
	if( a != NULL && b != NULL )
	{
		c = b->cnt - a->cnt;
	}
	return c;
}
