#include <stdio.h>
#include <string.h>
#include "tnode.h"

struct tnode** pos( struct tnode* treep , struct tnode** ptr)
{
	if( treep == NULL )
		return ptr;

	ptr = pos( treep->LC , ptr);
	*ptr = treep;
	ptr+=1;
	ptr = pos( treep->RC , ptr );

	return ptr;
}	
