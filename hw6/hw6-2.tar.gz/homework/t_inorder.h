#ifndef t_inorder_h
#define t_inorder_h

void t_inorder( struct tnode *treep );

#endif 

