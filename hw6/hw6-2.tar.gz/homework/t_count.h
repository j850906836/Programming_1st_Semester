#ifndef t_count_h
#define t_count_h

struct tnode** t_count( struct tnode * , int );
int mycompare( const void * , const void * );

#endif
