#ifndef t_delete_h
#define t_delete_h

struct tnode* t_delete( struct tnode* treep , char word[] );

#endif
