#include <stddef.h>
#include <string.h>
#include "tnode.h"
struct tnode* t_delete( struct tnode* , char [] );
struct tnode* t_delete( struct tnode* treep , char word[] )
{
	int c;
	if( treep == NULL )
		return NULL;
	c = strcmp( treep->key , word );
	
	if( c < 0 )
	{
		if( treep->RC == NULL )
			return NULL;
		else
		{
			 t_delete( treep->RC , word );
				return treep;
		}
	}
	
	else if( c == 0 )
	{
		if( treep->cnt > 0 )
			treep->cnt--;
		else
			treep->cnt = 0;
		return treep;
	}

	else if( c > 0 )
	{
		if( treep->LC == NULL )
			return NULL;
		else
		{
			t_delete( treep->LC , word );
				return treep;
		}
	}
	
	return NULL;
}	
