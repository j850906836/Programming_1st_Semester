#ifndef t_insert_h
#define t_insert_h

struct tnode* t_insert( struct tnode*, char[] );

#endif	 
