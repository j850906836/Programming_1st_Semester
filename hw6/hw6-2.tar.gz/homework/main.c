#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "tnode.h"
#include "t_insert.h"
#include "t_inorder.h"
#include "t_delete.h"
#include "t_find.h"
#include "t_count.h"
int main()
{
	struct tnode *treep , *ptr , *ptr1;
	struct tnode **dptr;	
	int len = 0;
 	char tmp[1004] = {0} , string[1004] = {0} , order[1004] = {0};
	while( fgets( tmp , 1004 , stdin ) )
	{
		sscanf( tmp , "%s\t%s" , order , string );
		if( strcmp( order , "insert" ) == 0 )
		{
			ptr1 = t_find( treep , string );
			if( ptr1 == NULL )
				len++;
			treep = t_insert( treep , string );	
		}
		else if( strcmp( order , "delete" ) == 0 )
		{
			treep = t_delete( treep , string );
		}
		else if( strcmp( order , "find" ) == 0 )
		{
			ptr = t_find( treep , string );
			if( ptr == NULL )
			printf("key not exists\n");	

			printf("find\n");
			printf("-------\n");
			printf("%s\t%d\n",ptr->key , ptr->cnt);
			printf("-------\n");
		}
		else if( strcmp( order , "inorder" ) == 0 )
		{
			printf("inorder\n");
			printf("--------\n");
			t_inorder( treep );
			printf("--------\n");	
		}
		else if( strcmp( order , "count" ) == 0 )
		{
		//	printf("%d\n",len);
			dptr = t_count( treep , len );
			printf("count\n");
			printf("----------\n");
			while( *dptr != NULL )
			{
				if((*dptr)->cnt > 0)
				{
					printf("%s\t%d\n",(*dptr)->key , (*dptr)->cnt);
				}
				dptr++;
			}	
			printf("---------\n");
		}
		memset( tmp , 0 , sizeof(tmp) );
		memset( string , 0 , sizeof(string) );
		memset( order , 0 , sizeof(order) );
	}
//	printf("%d\n",len);
	return 0;
}
